---
name: a3s-science-native-indication-dossier
description: Managed A3S Science catalog package for Indication dossier.
---

# Indication dossier

This package includes an A3S-native Skill with its adjacent scripts, references, and workflow assets.

## Package contract

- Kind: Skill
- Origin: native
- Source: https://github.com/A3S-Lab/Science/tree/main/claude-science/skills/indication-dossier
- Install: `a3s install use/a3s/native-indication-dossier`
- Upgrade: `a3s upgrade use/a3s/native-indication-dossier`
- Uninstall: `a3s uninstall use/a3s/native-indication-dossier`

## Safe use

1. Review the canonical source, license, data policy, and platform requirements.
2. Treat this package as a reproducible A3S entry point, not as an endorsement of scientific conclusions.
3. Preserve inputs, parameters, environment details, provenance, and output checksums.
4. Validate results against domain references before publication or operational use.
