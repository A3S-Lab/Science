---
name: a3s-science-eco-boltz
description: Managed A3S Science catalog package for Boltz.
---

# Boltz

This package installs a curated upstream knowledge card and integration contract. Verify upstream requirements before execution.

## Package contract

- Kind: Software
- Origin: ecosystem
- Source: https://github.com/jwohlwend/boltz
- Install: `a3s install use/a3s/eco-boltz`
- Upgrade: `a3s upgrade use/a3s/eco-boltz`
- Uninstall: `a3s uninstall use/a3s/eco-boltz`

## Safe use

1. Review the canonical source, license, data policy, and platform requirements.
2. Treat this package as a reproducible A3S entry point, not as an endorsement of scientific conclusions.
3. Preserve inputs, parameters, environment details, provenance, and output checksums.
4. Validate results against domain references before publication or operational use.
