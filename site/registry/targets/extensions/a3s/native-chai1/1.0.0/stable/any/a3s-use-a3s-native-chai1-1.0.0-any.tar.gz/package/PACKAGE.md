---
name: a3s-science-native-chai1
description: Managed A3S Science catalog package for Chai-1.
---

# Chai-1

This package includes an A3S-native Skill with its adjacent scripts, references, and workflow assets.

## Package contract

- Kind: Skill
- Origin: native
- Source: https://github.com/A3S-Lab/Science/tree/main/claude-science/skills/chai1
- Install: `a3s install use/a3s/native-chai1`
- Upgrade: `a3s upgrade use/a3s/native-chai1`
- Uninstall: `a3s uninstall use/a3s/native-chai1`

## Safe use

1. Review the canonical source, license, data policy, and platform requirements.
2. Treat this package as a reproducible A3S entry point, not as an endorsement of scientific conclusions.
3. Preserve inputs, parameters, environment details, provenance, and output checksums.
4. Validate results against domain references before publication or operational use.
