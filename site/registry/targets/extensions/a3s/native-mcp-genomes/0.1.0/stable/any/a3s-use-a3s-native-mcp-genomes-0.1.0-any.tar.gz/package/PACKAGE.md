---
name: a3s-science-native-mcp-genomes
description: Managed A3S Science catalog package for Genomes MCP.
---

# Genomes MCP

This package installs an MCP knowledge card and interface contract. Prepare the service runtime according to the canonical source requirements.

## Package contract

- Kind: MCP
- Origin: native
- Source: https://github.com/A3S-Lab/Science/tree/main/claude-science/mcp-servers/bio-tools/lib/mcp_genomes
- Install: `a3s install use/a3s/native-mcp-genomes`
- Upgrade: `a3s upgrade use/a3s/native-mcp-genomes`
- Uninstall: `a3s uninstall use/a3s/native-mcp-genomes`

## Safe use

1. Review the canonical source, license, data policy, and platform requirements.
2. Treat this package as a reproducible A3S entry point, not as an endorsement of scientific conclusions.
3. Preserve inputs, parameters, environment details, provenance, and output checksums.
4. Validate results against domain references before publication or operational use.
