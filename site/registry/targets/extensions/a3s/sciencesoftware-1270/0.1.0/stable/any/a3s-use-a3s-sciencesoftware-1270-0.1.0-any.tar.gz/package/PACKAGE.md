---
name: a3s-science-sciencesoftware-1270
description: Managed A3S Science catalog package for RiverTools 5.0.
---

# RiverTools 5.0

This package installs a knowledge card and clean-room modernization blueprint. It does not contain or license the original commercial binary.

## Package contract

- Kind: Software
- Origin: sciencesoftware
- Source: https://www.sciencesoftware.com.cn/web/details.html?id=1270
- Modernization roadmap: https://github.com/A3S-Lab/Science/blob/main/roadmaps/sciencesoftware-1270/ROADMAP.md
- Install: `a3s install use/a3s/sciencesoftware-1270`
- Upgrade: `a3s upgrade use/a3s/sciencesoftware-1270`
- Uninstall: `a3s uninstall use/a3s/sciencesoftware-1270`

## Safe use

1. Review the canonical source, license, data policy, and platform requirements.
2. Treat this package as a reproducible A3S entry point, not as an endorsement of scientific conclusions.
3. Preserve inputs, parameters, environment details, provenance, and output checksums.
4. Validate results against domain references before publication or operational use.
