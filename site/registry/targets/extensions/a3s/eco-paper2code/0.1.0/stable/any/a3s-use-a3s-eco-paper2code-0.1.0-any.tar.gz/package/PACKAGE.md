---
name: a3s-science-eco-paper2code
description: Managed A3S Science catalog package for Paper2Code.
---

# Paper2Code

This package installs a curated upstream knowledge card and integration contract. Verify upstream requirements before execution.

## Package contract

- Kind: Agent
- Origin: ecosystem
- Source: https://github.com/going-doer/Paper2Code
- Install: `a3s install use/a3s/eco-paper2code`
- Upgrade: `a3s upgrade use/a3s/eco-paper2code`
- Uninstall: `a3s uninstall use/a3s/eco-paper2code`

## Safe use

1. Review the canonical source, license, data policy, and platform requirements.
2. Treat this package as a reproducible A3S entry point, not as an endorsement of scientific conclusions.
3. Preserve inputs, parameters, environment details, provenance, and output checksums.
4. Validate results against domain references before publication or operational use.
