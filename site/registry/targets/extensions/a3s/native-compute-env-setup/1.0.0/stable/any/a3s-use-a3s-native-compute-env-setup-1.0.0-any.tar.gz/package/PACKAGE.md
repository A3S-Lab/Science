---
name: a3s-science-native-compute-env-setup
description: Managed A3S Science catalog package for Compute environment setup.
---

# Compute environment setup

This package includes an A3S-native Skill with its adjacent scripts, references, and workflow assets.

## Package contract

- Kind: Skill
- Origin: native
- Source: https://github.com/A3S-Lab/Science/tree/main/claude-science/skills/compute-env-setup
- Install: `a3s install use/a3s/native-compute-env-setup`
- Upgrade: `a3s upgrade use/a3s/native-compute-env-setup`
- Uninstall: `a3s uninstall use/a3s/native-compute-env-setup`

## Safe use

1. Review the canonical source, license, data policy, and platform requirements.
2. Treat this package as a reproducible A3S entry point, not as an endorsement of scientific conclusions.
3. Preserve inputs, parameters, environment details, provenance, and output checksums.
4. Validate results against domain references before publication or operational use.
