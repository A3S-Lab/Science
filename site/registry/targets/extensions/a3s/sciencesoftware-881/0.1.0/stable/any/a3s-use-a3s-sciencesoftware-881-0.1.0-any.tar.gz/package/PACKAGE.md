---
name: a3s-science-sciencesoftware-881
description: Managed A3S Science catalog package for Earth Volumetric Studio(EVS).
---

# Earth Volumetric Studio(EVS)

This package installs a knowledge card and clean-room modernization blueprint. It does not contain or license the original commercial binary.

## Package contract

- Kind: Software
- Origin: sciencesoftware
- Source: https://www.sciencesoftware.com.cn/web/details.html?id=881
- Modernization roadmap: https://github.com/A3S-Lab/Science/blob/main/roadmaps/sciencesoftware-881/ROADMAP.md
- Install: `a3s install use/a3s/sciencesoftware-881`
- Upgrade: `a3s upgrade use/a3s/sciencesoftware-881`
- Uninstall: `a3s uninstall use/a3s/sciencesoftware-881`

## Safe use

1. Review the canonical source, license, data policy, and platform requirements.
2. Treat this package as a reproducible A3S entry point, not as an endorsement of scientific conclusions.
3. Preserve inputs, parameters, environment details, provenance, and output checksums.
4. Validate results against domain references before publication or operational use.
