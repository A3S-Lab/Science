---
name: a3s-science-sciencesoftware-1447
description: Managed A3S Science catalog package for LORENTZ-HF.
---

# LORENTZ-HF

This package installs a knowledge card and clean-room modernization blueprint. It does not contain or license the original commercial binary.

## Package contract

- Kind: Software
- Origin: sciencesoftware
- Source: https://www.sciencesoftware.com.cn/web/details.html?id=1447
- Modernization roadmap: https://github.com/A3S-Lab/Science/blob/main/roadmaps/sciencesoftware-1447/ROADMAP.md
- Install: `a3s install use/a3s/sciencesoftware-1447`
- Upgrade: `a3s upgrade use/a3s/sciencesoftware-1447`
- Uninstall: `a3s uninstall use/a3s/sciencesoftware-1447`

## Safe use

1. Review the canonical source, license, data policy, and platform requirements.
2. Treat this package as a reproducible A3S entry point, not as an endorsement of scientific conclusions.
3. Preserve inputs, parameters, environment details, provenance, and output checksums.
4. Validate results against domain references before publication or operational use.
