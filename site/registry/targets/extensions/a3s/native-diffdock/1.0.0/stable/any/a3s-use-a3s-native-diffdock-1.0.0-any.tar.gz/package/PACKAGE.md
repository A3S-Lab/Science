---
name: a3s-science-native-diffdock
description: Managed A3S Science catalog package for DiffDock.
---

# DiffDock

This package includes an A3S-native Skill with its adjacent scripts, references, and workflow assets.

## Package contract

- Kind: Skill
- Origin: native
- Source: https://github.com/A3S-Lab/Science/tree/main/claude-science/skills/diffdock
- Install: `a3s install use/a3s/native-diffdock`
- Upgrade: `a3s upgrade use/a3s/native-diffdock`
- Uninstall: `a3s uninstall use/a3s/native-diffdock`

## Safe use

1. Review the canonical source, license, data policy, and platform requirements.
2. Treat this package as a reproducible A3S entry point, not as an endorsement of scientific conclusions.
3. Preserve inputs, parameters, environment details, provenance, and output checksums.
4. Validate results against domain references before publication or operational use.
