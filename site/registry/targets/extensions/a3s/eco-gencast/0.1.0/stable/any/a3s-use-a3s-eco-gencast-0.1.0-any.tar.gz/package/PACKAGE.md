---
name: a3s-science-eco-gencast
description: Managed A3S Science catalog package for GenCast.
---

# GenCast

This package installs a curated upstream knowledge card and integration contract. Verify upstream requirements before execution.

## Package contract

- Kind: Software
- Origin: ecosystem
- Source: https://github.com/google-deepmind/graphcast
- Install: `a3s install use/a3s/eco-gencast`
- Upgrade: `a3s upgrade use/a3s/eco-gencast`
- Uninstall: `a3s uninstall use/a3s/eco-gencast`

## Safe use

1. Review the canonical source, license, data policy, and platform requirements.
2. Treat this package as a reproducible A3S entry point, not as an endorsement of scientific conclusions.
3. Preserve inputs, parameters, environment details, provenance, and output checksums.
4. Validate results against domain references before publication or operational use.
