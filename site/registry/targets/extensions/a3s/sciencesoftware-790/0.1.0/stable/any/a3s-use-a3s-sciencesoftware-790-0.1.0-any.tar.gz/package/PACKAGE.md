---
name: a3s-science-sciencesoftware-790
description: Managed A3S Science catalog package for STRAD.
---

# STRAD

This package installs catalog metadata, classification, and a canonical source link. It does not contain or license the original software binary.

## Package contract

- Kind: Software
- Origin: sciencesoftware
- Source: https://www.sciencesoftware.com.cn/web/details.html?id=790
- Install: `a3s install use/a3s/sciencesoftware-790`
- Upgrade: `a3s upgrade use/a3s/sciencesoftware-790`
- Uninstall: `a3s uninstall use/a3s/sciencesoftware-790`

## Safe use

1. Review the canonical source, license, data policy, and platform requirements.
2. Treat this package as a reproducible A3S entry point, not as an endorsement of scientific conclusions.
3. Preserve inputs, parameters, environment details, provenance, and output checksums.
4. Validate results against domain references before publication or operational use.
